<?php


require_once "modele/profil.php";

getInfoProfil($_SESSION["utilisateur"]);

#var_dump($data);

echo "

        <main>
<div class='Page'>
<table>
   <div class='Titre'>
      <p> Profile et Infos </p>
   </div>
   <tr>
      <td>
         <div class='info'>Nom</div>
      </td>

   </tr>
   <tr>
      <td>
         <form action='profile' method='post'>
            <input type='text' name='SNom' class='ecrire' value=' $data[NOM]' ";
                
echo "affichage' > " ;
                
echo "
                <input type='submit' value='Confirmer' class='Envoyer'>
         </form>
      </td>
   </tr>
</table>
<table>
   <tr>
      <td>
         <div class='info'>Prenom</div>
      </td>

   </tr>
   <tr>
      <td>
         <form action='profile' method='post'>
            <input type='text' name='SPNom' class='ecrire' value=' $data[PRENOM] '>
            <input type='submit' value='Confirmer' class='Envoyer'>
         </form>
      </td>
   </tr>
</table>
<table>
   <tr>
      <td>
         <div class='info'>Pseudo</div>
      </td>
   </tr>
   <tr>
      <td>
            <input type='text' name='SPseu' value='$data[PSEUDO_U]' class='ecrire'>
            <input type='submit' value='Confirmer' class='Envoyer'>
      <td>
      </td>
</table>
<table>
   <tr>
      <td>
         <div class='info'>Age</div>
      </td>
   </tr>
   <tr>
      <td>
            <input type='text' name='SAge' value='$data[AGE]'class='ecrire'>
            <input type='submit' value='Confirmer' class='Envoyer'>
      <td>
      </td>
</table>
<table>
   <tr>
      <td>
         <div class='info'>Bio</div>
      </td>

   </tr>
   <tr>
      <td>
         <input type='text' name='SBio' value='$data[BIO]' class='ecrire'><input type='submit' value='Confirmer' class='Envoyer'>
      </td>
   </tr>
</table>
        <table>
         <tr>
            <td>
               <div class='info'>code postal</div>
            </td>

         </tr>
         <tr>
            <td>
               <input type='text' name='SCP' value=$data[CODE_POSTAL] class='ecrire'><input type='submit' value='Confirmer' class='Envoyer'>
            </td>
         </tr>
      </table>
<table>
   <tr>
      <td>
         <div class='info'>Tel</div>
      </td>
   </tr>
   <tr>
      <td>
         <input type='text' name='STel' value='$data[TEL]' class='ecrire'><input type='submit' value='Confirmer' class='Envoyer'>
      </td>
   </tr>
</table>

</div>
</main>";

?>
