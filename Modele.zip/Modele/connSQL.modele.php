<?php

function connexionSQL() {
    $login = "GAETAN";
    $mdp = "123456";
    $bd = "BD_RESTO_VIEW";
    $serveur = "localhost";
    
    $conn = mysqli_connect("localhost",$user,$mdp,$bd);
    return $conn
}

?>
