<?php

require_once "connSQL_modele.php";

function modif ()
{
	$conn=connexionSQL();
	if ($conn == FALSE)
	{
		echo "Erreur CONNEXION SQL";
	}
	
	$sql=("UPDATE PROFIL
	SET NOM = '$_POST[NOM]', 
	PRENOM = '$_POST[PRENOM]', 
	AGE = '$_POST[AGE]',
	BIO = '$_POST[BIO]',
	CODE_POSTAL = '$_POST[CODE_POSTAL]',
	DATE_NAISSANCE = '$_POST[DATE_NAISSANCE]',
	TEL = '$_POST[TEL]',
	CENTRE_FORMATION = '$_POST[CENTRE_FORMATION]',
	LANGUE = '$_POST[LANGUE]',
	MAIL = '$_POST[MAIL]'
	WHERE PSEUDO_U='$_SESSION[utilisateur]';");

	mysqli_query($conn,$sql);
}

?>
