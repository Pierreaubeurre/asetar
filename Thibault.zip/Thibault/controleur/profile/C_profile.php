<?php

function afficheProfile ()
{
   	 global $vueListe,$data;
    
    	//echo file_get_contents($vueListe["profile"]);
    
    	#var_dump($data);
    
    	$vue = file_get_contents($vueListe["profile"]);
	require_once "modele/profil.php";

	getInfoProfil();
	
	
	for ($i = 1;$i < 12; $i++)
	{
		$vue=str_replace("%$i"."R", "$data[$i]",$vue);
	}
	
	echo $vue;
} 
    
if (!isset ($_SESSION["utilisateur"]))//vérifie si le user est connecté , redirige sur login si non
{
	include_once "controleur/profile/js/pasco.php";
}

?>
