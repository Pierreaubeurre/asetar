<?php

echo "
	<script>
	window.alert('Vous devez vous connecter pour accéder à cette option');
	window.location.href = '?page=connexion';
	</script>";

?>
