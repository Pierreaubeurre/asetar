<?php

function afficheProfile ()//fonction d'affichage des données du profil
{
   	 global $vueListe,$data;
    
    
    	$vue = file_get_contents($vueListe["modifProfil"]);
	require_once "modele/profil.php";

	getInfoProfil($_SESSION["utilisateur"]);
	
	
	for ($i = 1;$i < 12; $i++)
	{
		$vue=str_replace("%$i"."R", "$data[$i]",$vue);
	}
	
	echo $vue;
}

function modifProfil()//fonction de changement du profil
{
	if ($_POST!=null)
	{
		require_once "modele/modifProfil_modele.php";
		modif();
	}	
}
    
    
    
   
if (!isset ($_SESSION["utilisateur"]))//vérifie si le user est connecté , redirige sur login si non
{
	include_once "controleur/profile/js/pasco.php";
}



?>
