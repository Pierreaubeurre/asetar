<?php

echo "
	<script>
	window.onload = function () {
		alert('Connexion établie');
		window.location.href = '?page=accueil';
	}
	</script>";

?>
