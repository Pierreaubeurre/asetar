<?php

/*

Fichier js

Remarque:

Ce fichier permet de rediriger l'utilisateur vers l'accueil quand il sait connecté


Fonction du controleur:

-Redirige l'utilisateur vers l'accueil
-Affiche une alerte "Connexion établie"

*/

echo "
	<script>
	window.onload = function () {
	window.location.href = '?page=accueil';
		alert('Connexion établie');
	}
	</script>";

?>
