<?php

/*
Fichier php de type : Controleur

Remarque:

Ce controleur permet à l'utilisateur de se connecter. Par conséquent, il utilise une superglobale cookie


Fonction du controleur:

-Récupère les information envoyées par le client en POST 
-Appel le modèle
-Vérifie le déroulement de l'authentification
-Envoie vers la page correspondant à la réussite ou non de l'authentification

 */
 
 
require_once "modele/authentification_modele.php";//Appel le modele pour l'authentification

if (isset ($_POST['user']) and isset ($_POST['password']))
{
	#$_POST["password"]=hash('gost',$_POST["password"]);
	authentification ($_POST['user'],$_POST['password']);//Fonction qui authentifie, change la valeur de $auth
}



 
function login ()
    {
    global $action,$vueListe,$auth;
    
    if ($auth==false) echo file_get_contents($vueListe["formLogin"]);
    else
        {
 
        include "controleur/login/js/connexion.php";
        $_SESSION["utilisateur"]=($_POST['user']);

        }
    }
?>

