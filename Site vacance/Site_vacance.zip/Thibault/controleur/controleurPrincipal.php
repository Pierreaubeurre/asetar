<?php

/*

Fichier php de type : Controleur

Remarque:

Ce controleur redirige le client vers la bonne page. Il permet donc aux serveurs d'envoyer la page demandé.
N'importe quelle page affichée passe d'abord par ce controleur.


Fonction du controleur:

-Lit la superglobale GET $page
-Envoie vers le controleur correspondant

*/


require_once "parametre/pageListe.php";//Liste des pages possibles

function mainControl (string $page="accueil")//A modifier si on rajoute des pages
{
	global $action;//Importe le tableau de la pageListe.php
	switch ($page)//Appel les pages correspondant à la demande
	{
		case "accueil"	:	require_once $action["accueil"];
					affAccueil();
					break;
		case "profile" :	require_once $action["visuProfile"];
					afficheProfile();
					break;
		case "connexion":	require_once $action["connexion"];
					login();
					break;
		case "inscription":	require_once $action["inscription"];
					break;
		case "modifProfil":	require_once $action["modifProfil"];
					modifProfil();
					afficheProfile();
					break;
		default:		require_once $action["accueil"];//Cas par défautl,si $page n'est pas égal à l'un des cas précédents
					affAccueil();
	}
}
	
?>

