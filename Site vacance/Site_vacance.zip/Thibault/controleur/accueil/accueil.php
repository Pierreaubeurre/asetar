<?php
/*

Fichier php de type : Controleur

Remarque:

Controleur par défaut.Affiche l'accueil

Fonction du controleur:

-Lit la vue html accueil
-Envoie la vue au client

*/


function affAccueil()//Fonction affichant la vue
{
    global $vueListe;
    echo file_get_contents($vueListe["accueil"]);

}
?>

