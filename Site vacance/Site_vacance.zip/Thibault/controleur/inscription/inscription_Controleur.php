<?php

/*

Fichier php de type : Controleur

Fonction du controleur:

-Lit la vue html inscription
-Envoie la vue au client
-Récupère les informations envoyés en POST par le client
-Met les informations sous une forme exploitable par le modèle, dans la variable $post
-Appel le modèle, utilise la fonction inscription avec $post en argument

*/


global $vueListe;
echo file_get_contents($vueListe["inscription"]);

require_once "modele/inscription_modele.php";

#if (isset ($_POST["password"]))//Verifie l'existence du post "password", évite une erreur
#{
#	$_POST["password"]=hash('gost',$_POST["password"]);
#}

$post=("'".(implode ("','",$_POST))."'") ;//Récupère les POST et les met sous la bonne forme
	
echo $post;
inscription($post);
?>
