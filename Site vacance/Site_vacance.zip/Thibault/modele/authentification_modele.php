<?php

/*

Fichier php de type : Modele

Remarque:

Ce modele vérifie si l'utilsateur et le mot de passe récupérés sont correct
Renvoie un booléen


Fonction du controleur:

-Récupère les informations envoyés par le controleur
-Fait une requête avec celle-ci cherchant une entrée correspondant aux informations
-Renvoie un booléen

*/

include "connSQL_modele.php";

$auth="";

function authentification ($nom,$mdpu)
{
	$conn=connexionSQL();
	if ($conn == FALSE)
	{
		echo "Erreur CONNEXION SQL";
	}
	

	$sql=("SELECT * FROM COMPTE WHERE PSEUDO_U='$nom' AND MDP_U='$mdpu';");
	$result=mysqli_query($conn,$sql);
	
	global $auth;
	
	
    	if (mysqli_affected_rows($conn)===1)
	{
		$auth=true;
	}
	else
	{
		$auth=false;
	}
}


?>

