<?php

/*

Fichier php de type : Modele

Remarque:

Ce modele établie la connexion à la bd grâce à l'utilisateur enregistré.Obligatoire pour manipuler la bd


Fonction du controleur:

-Etablie la connexion à la bd
-Renvoie la connexion sous la variable $conn

*/

function connexionSQL() {
    $login = "Admin";
    $mdp = "1234";
    $bd = "BD_ASETAR";
    $serveur = "localhost";
    
    $conn = mysqli_connect("localhost",$login,$mdp,$bd);
    return $conn;
}

?>
