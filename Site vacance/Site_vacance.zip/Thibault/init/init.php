<?php
/*

Fichier php de type : init

Remarque:

Ce fichier définie les paramètres Apache si celà est possible.
Il sert égalemant d'intermédiaire entre index.php et le controleur principale


Fonction du controleur:

-Lit la superglobale GET $page
-Envoie vers le controleur correspondant

*/



//Permet de définir les paramètres d'apache

//Active les erreurs
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

//Insert le controleur principal
require_once "controleur/controleurPrincipal.php"

?>

