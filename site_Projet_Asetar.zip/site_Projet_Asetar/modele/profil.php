<?php

include_once "connSQL_modele.php";

function getInfoProfil($nom) {
    $resultat = array();

    $conn=connexionSQL();
	if ($conn == FALSE)
	{
	echo "Erreur CONNEXION SQL";
	}
	$sql=("SELECT P.* FROM PROFIL P, COMPTE C WHERE C.NOM_U='$nom' AND C.NOM_U=P.NOM_U;");
	$resultat=mysqli_query($conn,$sql);
	
	global $resultat;
	
    return $resultat;
}
 
?>
