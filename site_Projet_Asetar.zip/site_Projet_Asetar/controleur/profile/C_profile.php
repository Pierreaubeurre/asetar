<?php

include_once "modele/profil.php";

function afficheProfile ()
    {
    global $vueListe,$auth;
    
    echo file_get_contents($vueListe["profile"]);

?>
