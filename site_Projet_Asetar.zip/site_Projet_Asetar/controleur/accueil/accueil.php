<?php

global $vueListe;
echo file_get_contents($vueListe["accueil"]);
?>

