<?php

	$action= array();
	$action["accueil"]="login/login.php";
	$action["connexion"]="login/login.php";
	
	$vueListe= array();
	$vueListe["entete"]=		"vue/header";
	$vueListe["pied"]=		"vue/foot.html";
	$vueListe["formLogin"]=	"vue/login/Connexion.html";
	$vueListe["accueil"]=		"vue/Accueil";


?>
