<!DOCTYPE html>
<html>
    <body>
        <meta charset="utf-8">
        <!-- importer le fichier css -->
        <link rel="stylesheet" href="Connexion.css" type="text/css"/>
        
            <div id="container">
            <!-- zone de connexion -->

                <form action="#" method="post">
                    <h1>Connexion</h1>
                    
                    <div class="user-details">
                        <div class="input-box">
                            <span class="details">Nom d'utilisateur</span>
                            <input type="text" placeholder="Entrer votre d'utilisateur" required>
                        </div>
                        
                    <div class="user-details">
                        <div class="input-box">
                            <span class="details">Mot de passe</span>
                            <input type="password" placeholder="Entrer votre mot de passe" required>
                        </div>

                    <div class="pass"><a href="./?page=mdpOublie">Mot de passe oublié ?</a></div>
                    
                        <button type="submit" formaction="index.php">Connexion</button>

                    <div class="pass">Voulez-vous vous inscrire ? <a href="./?page=Inscription">Inscription.</a></div>
                    </div>
                </form>
            </div>
        </body>
    </html>
