<?php

include "$racine/vue/connexion.html";
//à remplacer, le chemin est absolu ,voir AP
?>
