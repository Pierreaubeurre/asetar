<?php

include "$racine/vue/boutique.html";
//à remplacer, le chemin est absolu ,voir AP
?>
