<?php

include "$racine/vue/PageAccueil.html";
//à remplacer, le chemin est absolu ,voir AP
?>
