<?php
/*
    -------------------------------------------------
    SIO1 SLAM - Projet ASETAR - Mars 2022 PF
    => Partie 1 :
    -------------------------------------------------
*/

$ctrlList = array();
$ctrlList["home"]    = "login/login.php";   //0 Pour test !!
$ctrlList["login"]   = "login/login.php";   //1
$ctrlList["games"]   = "";                  //2
$ctrlList["forums"]  = "";                  //3
$ctrlList["shop"]    = "";                  //4
$ctrlList["profile"] = "";                  //5

$viewList = array();
$viewList["head"]           = "view/head.html";               //0
$viewList["foot"]           = "view/foot.html";               //1
$viewList["formLogin"]      = "view/login/loginForm.html";    //2


?>
