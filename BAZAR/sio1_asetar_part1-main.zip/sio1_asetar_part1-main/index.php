 <?php
/*
    -------------------------------------------------
    SIO1 SLAM - Projet ASETAR - Mars 2022 PF
    => Partie 1 : AUTH + cookie
    -------------------------------------------------
*/

// Insertion du contrôleur principal
require_once "init/init.php";

// Si action demandée ...
if (isset($_GET["action"])) $action=$_GET["action"];
else $action="home"; // ... sinon page d'accueil par défaut

// Appel du CP avec l'action demandée
mainControl($action);
?>
