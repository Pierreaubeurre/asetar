<?php
/*
    SIO1 SLAM - Projet ASETAR - Mars 2022 PF
    => Partie 1
*/

// Pour debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Insertion du contrôleur principal
require_once "controller/mainControl.php";

?>
