<?php

/**
 * Contrôleur de la partie login
 */
function login ()
    {
    global $viewList;
    //var_dump($_GET);
    if (!isset($_GET["user"])) echo file_get_contents($viewList["formLogin"]);
    else
        {
        //Partie supérieure page (HEAD + haut du BODY)
        echo file_get_contents($viewList["head"]);
        
        echo "<br><div class='title'> => Contenu du tab. global \$_GET </div>";
        var_dump ($_GET);
        echo "<br><br><div class='title'> => Contenu du tab. global \$_POST </div>";
        var_dump ($_POST);
        echo "<br><br><div class='title'> => Contenu du cookie </div>";
        var_dump ($_COOKIE);
        //Partie inférieure page (bas du BODY + fin HTML)
        echo file_get_contents($viewList["foot"]);
        }
    }

?>
