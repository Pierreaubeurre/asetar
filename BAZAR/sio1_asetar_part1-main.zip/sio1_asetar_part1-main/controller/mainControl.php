<?php
/*
    -------------------------------------------------
    SIO1 SLAM - Projet ASETAR - Mars 2022 PF
    => Partie 1 : AUTH + cookie
    -------------------------------------------------
*/

// Liste des actions possibles + param.
require_once "param/actionsList.php";

/**
 * Contrôleur Principal
 * @param string $action Action à traiter
 */
function mainControl (string $action="home")
    {
    /* ==> Cookie HTTP et session PHP
     * Voir : https://www.php.net/manual/fr/function.session-start.php
     * et : https://www.php.net/manual/fr/reserved.variables.session.php
     * et : https://www.php.net/manual/fr/reserved.variables.cookies.php
     */
    //session_start();
    global $ctrlList;
    switch ($action)
        {
        case "login"    :   require_once $ctrlList["login"];
                            login();
                            break;
        case "profile"  :   require_once $ctrlList["profile"];
                            profile();
                            break;
        case "shop"     :   require_once $ctrlList["shop"];
                            shop();
                            break;
        case "home"     :   require_once $ctrlList["home"];
                            login();
                            break;


        /* ... */

        }
    }


?>
