<?php
global $vueListe;
echo file_get_contents($vueListe["inscription"]);

require_once "modele/inscription_modele.php";
inscription();
?>
