<?php
include "connSQL_modele.php";

$auth="";

function authentification ($nom,$mdpu)
{
	$conn=connexionSQL();
	if ($conn == FALSE)
	{
	echo "Erreur CONNEXION SQL";
	}
	

	$sql=("SELECT * FROM COMPTE WHERE NOM_U='$nom' AND MDP_U='$mdpu';");
	$result=mysqli_query($conn,$sql);
	
	global $auth;
	
    if (mysqli_affected_rows($conn)===1)
	{
		$auth=true;
	}
	else
	{
		$auth=false;
	}
}
?>

