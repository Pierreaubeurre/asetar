<?php

require_once "connSQL_modele.php";

function inscription ()
{
	$conn=connexionSQL();
	if ($conn == FALSE)
	{
	echo "Erreur CONNEXION SQL";
	}
	
	$post=("'".(implode ("','",$_POST))."'") ;//Récupère les POST et les met sous la bonne forme
	
	mysqli_query($conn,"INSERT INTO COMPTE (NOM_U,MDP_U) 
VALUES ($post)");//Envoie la requete avec l'information récupéré en POST
}


?>
